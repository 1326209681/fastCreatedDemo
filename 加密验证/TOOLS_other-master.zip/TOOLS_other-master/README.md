# TOOLS
项目工具<br/>
(1)safety模块，和互联网安全相关的工具类<br/>
(2)validate模块，和验证码相关的工具类<br/>
