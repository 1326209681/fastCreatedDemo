package com.liutao.util;

public class StringUtils {
    public static boolean isEmpty(String templateFiletype) {
        return templateFiletype == null || templateFiletype.equals("");
    }
}
